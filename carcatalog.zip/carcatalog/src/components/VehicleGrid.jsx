import VehicleCard from "./VehicleCard";

export default function VehicleGrid(){
    return(
        <div style = {{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '20px', padding: '20px'}}>
            {car.map(car => (
                <VehicleCard key = {car.id} car = {car} onClick={onCarClick} />
            ))}
        </div>
    );
}